# ponzi-investment-system

This is a basic ponzi investment scheme website developed with the LAMP stack. The PHP version is PHP 7. 
Users register on the website, and when they complete their registration, they are matched to an upline. 

<br>

<b>INSTALLATION</b>

<br>

This system can be implement using the XAMPP server.
