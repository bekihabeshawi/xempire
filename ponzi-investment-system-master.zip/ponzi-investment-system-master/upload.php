<?php

//initialize the session
if (!isset($_SESSION)) {
  session_start();
}

require_once('./Connections/MMM.php');

?>


<?

$my_email = $_SESSION['MM_Username'];

mysql_select_db($database_MMM, $MMM);

$sql = mysql_query("SELECT * FROM `register` WHERE Email = '$my_email' ") or die(mysql_error());


 while($row = mysql_fetch_array($sql)) {
	 	 
	 $id  = $row['id']; 	
	 $Fullnames = $row['Fullnames'];  	
	 $Username = $row['Username'];  	
	 $Phone = $row['Phone'];  	
	 $Email = $row['Email'];  	
	 $Password = $row['Password'];  	
	 $Bank = $row['Bank'];  	
	 $Account = $row['Account'];  	
	 $Matched = $row['Matched'];  	
	 $ReceiveMoney = $row['ReceiveMoney'];  	
	 $Package =  $row['Package']; 
	 $Status =  $row['Status']; 
	 
 }
 

echo "Full names is: " .$Fullnames;
?>


<!DOCTYPE html>
<html lang="en">

<meta http-equiv="content-type" content="text/html;charset=UTF-8" />
<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>matrix fund</title>

    <!-- Bootstrap Core CSS -->
    <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom Fonts -->
    <link href="vendor/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">
    <link href='https://fonts.googleapis.com/css?family=Open+Sans:300italic,400italic,600italic,700italic,800italic,400,300,600,700,800' rel='stylesheet' type='text/css'>
    <link href='https://fonts.googleapis.com/css?family=Merriweather:400,300,300italic,400italic,700,700italic,900,900italic' rel='stylesheet' type='text/css'>

    <!-- Plugin CSS -->
    <link href="vendor/magnific-popup/magnific-popup.css" rel="stylesheet">

    <!-- Theme CSS -->
    <link href="css/creative.min.css" rel="stylesheet">

   

</head>

<body id="page-top">
		
<nav id="mainNav" class="navbar navbar-default navbar-fixed-top affix">
        <div class="container-fluid">
            <!-- Brand and toggle get grouped for better mobile display -->
            <div class="navbar-header">
                <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
                    <span class="sr-only">Toggle navigation</span> Menu <i class="fa fa-bars"></i>
                </button>
                <a class="navbar-brand page-scroll" href="#page-top">matrixfund</a>
            </div>

            <!-- Collect the nav links, forms, and other content for toggling -->
            <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                <ul class="nav navbar-nav navbar-right">
                   
                    <li>
                        <a class="page-scroll" href="dashboard.php">Dashborad</a>
                    </li>
                    <li>
                        <a class="page-scroll" href="./apply.php">Packages</a>
                    </li>
                    <li class="">
                        <a class="page-scroll" href="#contact">Contact</a>
                    </li>
					<li>
                        <a href="<?php echo $logoutAction ?>" class="page-scroll" >Logout</a>
                    </li>
                </ul>
            </div>
            <!-- /.navbar-collapse -->
        </div>
        <!-- /.container-fluid -->
    </nav>

    <header>
        <div class="header-content">
            <div class="header-content-inner">
                
				<h3 id="homeHeading">Response</h3>
                <hr>
                
				
				<p>
				
				<?php
$target_dir = "uploads/";
$target_file = $target_dir . basename($_FILES["fileToUpload"]["name"]);
$uploadOk = 1;
$imageFileType = pathinfo($target_file,PATHINFO_EXTENSION);
// Check if image file is a actual image or fake image
if(isset($_POST["submit"])) {
    $check = getimagesize($_FILES["fileToUpload"]["tmp_name"]);
    if($check !== false) {
        echo "File is an image - " . $check["mime"] . ".";
        $uploadOk = 1;
    } else {
        echo "File is not an image.";
        $uploadOk = 0;
    }
}

// Check file size
if ($_FILES["fileToUpload"]["size"] > 500000) {
    echo "Sorry, your file is too large.";
    $uploadOk = 0;
}
// Allow certain file formats
else if($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg"
&& $imageFileType != "gif" ) {
    echo "Sorry, only JPG, JPEG, PNG & GIF files are allowed.";
    $uploadOk = 0;
}

// Check if file already exists
if (file_exists($target_file)) {
    echo " &nbsp; File may be empty or already exists.";
    $uploadOk = 0;
}

// Check if $uploadOk is set to 0 by an error
else if ($uploadOk == 0) {
    echo "Sorry, your file was not uploaded. ";
// if everything is ok, try to upload file
} else {
    if (move_uploaded_file($_FILES["fileToUpload"]["tmp_name"], $target_file)) {
        echo "The file ". basename( $_FILES["fileToUpload"]["name"]). " has been uploaded.";
        $query1 = "UPDATE register SET Status = 'Your proof of payment was uploaded successfully. <br/> Please wait for confirmation of your payment. We will pair you to someone to pay you once confirmed' WHERE Email = '$Email' "; 
$sql1 = mysql_query($query1);

header("location: ./dashboard.php");

        //echo "<button>CONTINUE</button>";
    } else {
        echo "Sorry, there was an error uploading your file.";
    }
}
?>

</p>
</div>
</div>
</header>



